package com.example.mcvoice

import android.app.Service
import android.content.ContentValues
import android.content.Intent
import android.content.pm.ServiceInfo
import android.hardware.display.DisplayManager
import android.media.*
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Bundle
import android.os.IBinder
import android.os.ParcelFileDescriptor
import android.provider.MediaStore
import android.util.Log
import java.nio.ByteBuffer
import java.nio.ByteOrder

/**
 * Graba pantalla + audio en un MP4 (Películas/MCVoice).
 * Audio = [tu voz + voces de amigos, mezcladas por la página y enviadas con pushAudio]
 *       + [audio de otras apps, p. ej. Minecraft, vía captura de audio del sistema].
 * Soporta pausa: mientras está en pausa no se escribe video ni audio.
 */
class RecorderService : Service() {
    companion object {
        @Volatile var running = false
        @Volatile var paused = false
    }

    private var projection: MediaProjection? = null
    private var worker: Thread? = null
    @Volatile private var stopFlag = false

    private class Pending(val track: Int, val data: ByteBuffer, val info: MediaCodec.BufferInfo)

    override fun onBind(i: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (worker != null) return START_NOT_STICKY
        val code = intent?.getIntExtra("code", 0) ?: 0
        @Suppress("DEPRECATION")
        val data: Intent? = if (Build.VERSION.SDK_INT >= 33)
            intent?.getParcelableExtra("data", Intent::class.java) else intent?.getParcelableExtra("data")
        if (data == null) { stopSelf(); return START_NOT_STICKY }

        startForeground(
            2, buildNotif("Grabando pantalla"),
            ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION or ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE
        )
        val mpm = getSystemService(MediaProjectionManager::class.java)
        val p = mpm.getMediaProjection(code, data)
        p.registerCallback(object : MediaProjection.Callback() {
            override fun onStop() { stopFlag = true }
        }, null)
        projection = p

        paused = false
        Pcm.clear()
        running = true
        BubbleService.instance?.refresh()
        worker = Thread {
            var err: String? = null
            try { record(p) } catch (e: Exception) { Log.e("Rec", "falló la grabación", e); err = e.javaClass.simpleName + ": " + e.message }
            running = false
            paused = false
            BubbleService.instance?.refresh()
            MainActivity.runJs("onRecState(false)")
            android.os.Handler(android.os.Looper.getMainLooper()).post {
                android.widget.Toast.makeText(
                    applicationContext,
                    if (err == null) "Grabación terminada. Revisa Películas/MCVoice" else "No se pudo grabar: $err",
                    android.widget.Toast.LENGTH_LONG
                ).show()
            }
            stopSelf()
        }.also { it.start() }
        return START_NOT_STICKY
    }

    private fun record(p: MediaProjection) {
        // ---- Video (máx. ~720p, múltiplos de 16)
        val dm = resources.displayMetrics
        val sc = minOf(1f, 720f / minOf(dm.widthPixels, dm.heightPixels))
        val w = ((dm.widthPixels * sc).toInt() / 16) * 16
        val h = ((dm.heightPixels * sc).toInt() / 16) * 16
        val vf = MediaFormat.createVideoFormat("video/avc", w, h).apply {
            setInteger(MediaFormat.KEY_COLOR_FORMAT, MediaCodecInfo.CodecCapabilities.COLOR_FormatSurface)
            setInteger(MediaFormat.KEY_BIT_RATE, 5_000_000)
            setInteger(MediaFormat.KEY_FRAME_RATE, 30)
            setInteger(MediaFormat.KEY_I_FRAME_INTERVAL, 1)
        }
        val venc = MediaCodec.createEncoderByType("video/avc")
        venc.configure(vf, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE)
        val surface = venc.createInputSurface()
        venc.start()
        val display = p.createVirtualDisplay(
            "mcvoice", w, h, dm.densityDpi,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, surface, null, null
        )

        // ---- Audio
        val rate = 44100
        val frame = 1024
        val afmt = AudioFormat.Builder().setEncoding(AudioFormat.ENCODING_PCM_16BIT)
            .setSampleRate(rate).setChannelMask(AudioFormat.CHANNEL_IN_MONO).build()
        val bufSize = maxOf(
            AudioRecord.getMinBufferSize(rate, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT), 8192
        ) * 2

        // Audio de otras apps (Minecraft). Se excluye esta app: sus voces ya llegan mezcladas por la página.
        fun capture(exclude: Boolean): AudioRecord {
            val b = AudioPlaybackCaptureConfiguration.Builder(p)
                .addMatchingUsage(AudioAttributes.USAGE_MEDIA)
                .addMatchingUsage(AudioAttributes.USAGE_GAME)
                .addMatchingUsage(AudioAttributes.USAGE_UNKNOWN)
            if (exclude) b.excludeUid(android.os.Process.myUid())
            return AudioRecord.Builder().setAudioPlaybackCaptureConfig(b.build())
                .setAudioFormat(afmt).setBufferSizeInBytes(bufSize).build()
        }
        val playback: AudioRecord? = try { capture(true) } catch (e: Exception) {
            Log.w("Rec", "captura con exclusión falló", e)
            try { capture(false) } catch (e2: Exception) { Log.w("Rec", "sin audio del sistema", e2); null }
        }

        val af = MediaFormat.createAudioFormat("audio/mp4a-latm", rate, 1).apply {
            setInteger(MediaFormat.KEY_AAC_PROFILE, MediaCodecInfo.CodecProfileLevel.AACObjectLC)
            setInteger(MediaFormat.KEY_BIT_RATE, 128_000)
            setInteger(MediaFormat.KEY_MAX_INPUT_SIZE, 16384)
        }
        val aenc = MediaCodec.createEncoderByType("audio/mp4a-latm")
        aenc.configure(af, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE)
        aenc.start()

        // ---- Archivo de salida
        val values = ContentValues().apply {
            put(MediaStore.Video.Media.DISPLAY_NAME, "MCVoice_${System.currentTimeMillis()}.mp4")
            put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
            put(MediaStore.Video.Media.RELATIVE_PATH, "Movies/MCVoice")
            put(MediaStore.Video.Media.IS_PENDING, 1)
        }
        val uri = contentResolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, values)!!
        val pfd: ParcelFileDescriptor = contentResolver.openFileDescriptor(uri, "rw")!!
        val muxer = MediaMuxer(pfd.fileDescriptor, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)

        var vTrack = -1; var aTrack = -1; var started = false
        val pending = ArrayList<Pending>()
        var lastV = -1L; var lastA = -1L
        val t0 = System.nanoTime()
        val baseUs = t0 / 1000
        var pauseOffsetUs = 0L
        var dropVideo = false
        var needKey = false

        fun maybeStart() {
            if (!started && vTrack >= 0 && aTrack >= 0) {
                muxer.start(); started = true
                for (pd in pending) muxer.writeSampleData(pd.track, pd.data, pd.info)
                pending.clear()
            }
        }

        fun drain(codec: MediaCodec, video: Boolean): Boolean {
            val info = MediaCodec.BufferInfo()
            var eos = false
            while (true) {
                val idx = codec.dequeueOutputBuffer(info, 0)
                when {
                    idx == MediaCodec.INFO_TRY_AGAIN_LATER -> return eos
                    idx == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED -> {
                        val t = muxer.addTrack(codec.outputFormat)
                        if (video) vTrack = t else aTrack = t
                        maybeStart()
                    }
                    idx >= 0 -> {
                        val buf = codec.getOutputBuffer(idx)!!
                        if (info.flags and MediaCodec.BUFFER_FLAG_CODEC_CONFIG != 0) info.size = 0
                        if (info.size > 0) {
                            var write = true
                            if (video) {
                                if (dropVideo) write = false
                                else if (needKey) {
                                    if (info.flags and MediaCodec.BUFFER_FLAG_KEY_FRAME != 0) needKey = false else write = false
                                }
                            }
                            if (write) {
                                var pts = if (video) info.presentationTimeUs - baseUs - pauseOffsetUs else info.presentationTimeUs
                                val last = if (video) lastV else lastA
                                if (pts <= last) pts = last + 1
                                if (video) lastV = pts else lastA = pts
                                info.presentationTimeUs = pts
                                buf.position(info.offset); buf.limit(info.offset + info.size)
                                val track = if (video) vTrack else aTrack
                                if (started) muxer.writeSampleData(track, buf, info)
                                else {
                                    val copy = ByteBuffer.allocate(info.size); copy.put(buf); copy.flip()
                                    val ci = MediaCodec.BufferInfo(); ci.set(0, info.size, pts, info.flags)
                                    pending.add(Pending(track, copy, ci))
                                }
                            }
                        }
                        if (info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM != 0) eos = true
                        codec.releaseOutputBuffer(idx, false)
                    }
                }
            }
        }

        playback?.startRecording()
        val mixIn = ShortArray(frame); val pb = ShortArray(frame); val out = ShortArray(frame)
        var frameIdx = 0L
        var pausedAtUs = -1L
        var lastAudioPts = 0L
        var vDone = false; var aDone = false; var eosSent = false; var deadline = 0L

        while (!(vDone && aDone)) {
            if (!stopFlag) {
                // Reloj: un bloque de audio cada ~23 ms
                val targetNs = t0 + frameIdx * frame * 1_000_000_000L / rate
                val waitMs = (targetNs - System.nanoTime()) / 1_000_000
                if (waitMs > 0) Thread.sleep(waitMs)
                val clockUs = (targetNs - t0) / 1000
                frameIdx++

                if (paused) {
                    if (pausedAtUs < 0) pausedAtUs = clockUs
                    dropVideo = true
                    Pcm.take(mixIn, frame)                                       // descartar
                    playback?.read(pb, 0, frame, AudioRecord.READ_NON_BLOCKING)  // descartar
                } else {
                    if (pausedAtUs >= 0) {                                       // se reanudó
                        pauseOffsetUs += clockUs - pausedAtUs
                        pausedAtUs = -1
                        dropVideo = false; needKey = true
                        val bn = Bundle(); bn.putInt(MediaCodec.PARAMETER_KEY_REQUEST_SYNC_FRAME, 0)
                        venc.setParameters(bn)
                    }
                    val n1 = Pcm.take(mixIn, frame)
                    val n2 = if (playback != null) maxOf(playback.read(pb, 0, frame, AudioRecord.READ_NON_BLOCKING), 0) else 0
                    for (i in 0 until frame) {
                        val x = if (i < n1) mixIn[i].toInt() else 0
                        val y = if (i < n2) pb[i].toInt() else 0
                        out[i] = (x + y).coerceIn(-32768, 32767).toShort()
                    }
                    val ii = aenc.dequeueInputBuffer(5_000)
                    if (ii >= 0) {
                        val ib = aenc.getInputBuffer(ii)!!
                        ib.clear(); ib.order(ByteOrder.LITTLE_ENDIAN)
                        ib.asShortBuffer().put(out, 0, frame)
                        val pts = clockUs - pauseOffsetUs
                        lastAudioPts = pts
                        aenc.queueInputBuffer(ii, 0, frame * 2, pts, 0)
                    }
                }
            } else if (!eosSent) {
                venc.signalEndOfInputStream()
                var tries = 0
                while (tries++ < 50) {
                    val ii = aenc.dequeueInputBuffer(20_000)
                    if (ii >= 0) {
                        aenc.queueInputBuffer(ii, 0, 0, lastAudioPts + 1000, MediaCodec.BUFFER_FLAG_END_OF_STREAM)
                        break
                    }
                }
                eosSent = true; deadline = System.currentTimeMillis() + 3000
            } else {
                Thread.sleep(10)
                if (System.currentTimeMillis() > deadline) break
            }
            if (drain(venc, true)) vDone = true
            if (drain(aenc, false)) aDone = true
        }

        // ---- Cierre
        try { if (started) muxer.stop() } catch (e: Exception) { Log.e("Rec", "muxer", e) }
        runCatching { muxer.release() }
        runCatching { display.release() }
        runCatching { venc.stop(); venc.release() }
        runCatching { aenc.stop(); aenc.release() }
        runCatching { playback?.stop(); playback?.release() }
        runCatching { pfd.close() }
        if (started) {
            val v = ContentValues().apply { put(MediaStore.Video.Media.IS_PENDING, 0) }
            contentResolver.update(uri, v, null, null)
        } else contentResolver.delete(uri, null, null)
    }

    override fun onDestroy() {
        stopFlag = true
        worker?.join(5000)
        projection?.stop()
        super.onDestroy()
    }
}
