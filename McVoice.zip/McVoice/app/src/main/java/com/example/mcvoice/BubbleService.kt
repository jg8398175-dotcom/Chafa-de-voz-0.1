package com.example.mcvoice

import android.app.Service
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.view.Gravity
import android.view.MotionEvent
import android.view.WindowManager
import android.widget.TextView

/** Burbuja flotante: toca para silenciar / activar el micrófono. Arrástrala donde quieras. */
class BubbleService : Service() {
    companion object {
        var instance: BubbleService? = null
        @Volatile var mode = 1
    }
    private lateinit var wm: WindowManager
    private var bubble: TextView? = null
    private val main = Handler(Looper.getMainLooper())

    override fun onBind(i: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        instance = this
        wm = getSystemService(WindowManager::class.java)
        val d = resources.displayMetrics.density
        val size = (58 * d).toInt()
        val tv = TextView(this).apply { gravity = Gravity.CENTER; textSize = 24f }
        val lp = WindowManager.LayoutParams(
            size, size, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.START; x = (12 * d).toInt(); y = (220 * d).toInt() }

        var sx = 0; var sy = 0; var tx = 0f; var ty = 0f; var moved = false
        tv.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> { sx = lp.x; sy = lp.y; tx = e.rawX; ty = e.rawY; moved = false }
                MotionEvent.ACTION_MOVE -> {
                    val dx = e.rawX - tx; val dy = e.rawY - ty
                    if (Math.abs(dx) > 12 * d || Math.abs(dy) > 12 * d) moved = true
                    if (moved) { lp.x = sx + dx.toInt(); lp.y = sy + dy.toInt(); wm.updateViewLayout(tv, lp) }
                }
                MotionEvent.ACTION_UP -> if (!moved) MainActivity.runJs("toggleMute()")
            }
            true
        }
        wm.addView(tv, lp)
        bubble = tv
        refresh()
    }

    fun refresh() {
        main.post {
            val tv = bubble ?: return@post
            val bg = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(when (mode) {
                    2 -> Color.parseColor("#555B61")
                    3 -> Color.parseColor("#B06A1D")
                    else -> Color.parseColor("#3D7524")
                })
                if (RecorderService.running) setStroke((4 * resources.displayMetrics.density).toInt(), Color.parseColor("#D8392B"))
            }
            tv.background = bg
            tv.text = when (mode) {
                2 -> "🔇"
                3 -> "🙉"
                else -> "🎤"
            }
        }
    }

    override fun onDestroy() {
        instance = null
        bubble?.let { runCatching { wm.removeView(it) } }
        bubble = null
        super.onDestroy()
    }
}
