package com.example.mcvoice

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context

fun Context.buildNotif(text: String): Notification {
    val nm = getSystemService(NotificationManager::class.java)
    nm.createNotificationChannel(
        NotificationChannel("mcvoice", "MC Voice", NotificationManager.IMPORTANCE_LOW)
    )
    return Notification.Builder(this, "mcvoice")
        .setContentTitle("MC Voice")
        .setContentText(text)
        .setSmallIcon(android.R.drawable.ic_btn_speak_now)
        .setOngoing(true)
        .build()
}
